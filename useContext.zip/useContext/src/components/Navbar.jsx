import Component from "./Component"

function Navbar() {
  return (
    <div>
        <Component/>
    </div>
  )
}

export default Navbar