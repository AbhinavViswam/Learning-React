import { createContext } from "react";

const CountContext=createContext()

// const countCtx=countContext.Provider

export default CountContext;